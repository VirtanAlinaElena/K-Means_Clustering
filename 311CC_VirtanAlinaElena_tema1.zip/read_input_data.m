% dechid primul fisier, citesc numarul de centroizi NC, inchid fisierul
% deschid al doilea fisier, citesc matricea sarind peste primele cinci linii
% pe care sunt comentarii si specific formatul datelor citite  
function [NC points] = read_input_data(file_params, file_points)
	NC = 0;
	points = [];

	fid = fopen(file_params, 'r');
  NC = fscanf(fid, "%d");
  fclose(fid);
  
  fid = fopen(file_points, 'r');
  % specific formatul datelor pentru a extrage toate zecimalele din fisier
  format long g;
  points = dlmread(fid, ' ', 5, 0);
  fclose(fid);
end

