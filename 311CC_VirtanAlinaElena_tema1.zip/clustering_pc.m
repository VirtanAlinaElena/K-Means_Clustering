function [centroids] = clustering_pc(points, NC)
  centroids = [];
  % alegerea aleatoare a celor NC centroizi
  linPoints = size(points, 1);
  colPoints = size(points, 2);
  centroids = zeros(NC, colPoints); 
  randpoints = randperm(linPoints, NC);
  centroids = points(randpoints, :);
  
  %presupun ca nu am gasit pozitii fixe ale centroizilor 
  ok = 0;  
  while (ok == 0)
  % fiecare punct din multime e atribuit grupului reprezentat de cel mai
                                                      %apropiat centroid
    linCentroids = size(centroids, 1); 
   % initializez vectorul care asociaza fiecarui punct centroidul corespunzator
    indices = zeros(linPoints, 1);
                  
    for i = 1 : linPoints
    %{ 
     calculez distanta euclidiana de la punctul i la fiecare centroid si 
     asociez punctului centroidul la care distanta e minima 
    %}
      k = 1; 
      distMin = sum((points(i, :) - centroids(1,:)) .^ 2);
      for j = 2 : linCentroids
        dist = sum((points(i, :) - centroids(j, :)) .^ 2);
        if (dist < distMin )
          distMin = dist;
          k = j;
        endif
      endfor
      indices(i) = k;
    endfor
    
    old_centroids = centroids;
    % recalcularea pozitiilor centroizilor
    centroids = zeros(NC, colPoints);
    for i = 1 : NC
      % memorez punctele care apartin clusterului i
      xi = points(indices == i, :);
      % numarul de puncte care apartin clusterului i
      nr = size(xi, 1);
      % valorea centroidului corespunzator clusterului i se calculeaza ca fiind
      % media aritmetica a punctelor care apartin clusterului respectiv
      centroids(i, :) = (1/nr) * [sum(xi(:, 1)) sum(xi(:, 2)) sum(xi(:, 3))]; 
    endfor
    if (old_centroids == centroids) 
      ok = 1;
    endif
  endwhile
end