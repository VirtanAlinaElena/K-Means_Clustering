function view_cost_vs_nc(file_points)
	% deschid fisierul, memorez in variabila points matricea care contine
  % coordonatele punctelor si inchid fiserul
	points = [];
  fid = fopen(file_points, 'r');
  format long g;
  points = dlmread(fid, ' ', 5, 0);
  fclose(fid);
  
  % calculez costul fiecarei solutii in cazul in care numarul de centroizi ia
  % valori de la 1 la 10 si memorez rezultatele in matricea cost
  cost = [];
  for NC = 1 : 10
    centroids = clustering_pc(points, NC);
    cost(NC) = compute_cost_pc(points, centroids);
  endfor
  
  % trasez graficul ca fiind dependenta functiei cost de parametrul NC, care
  % ia valori de la 1 la 10
  NC = [1:10];
  plot(NC, cost);
  xlabel('Cluster count'); 
  ylabel('Cost');
end

