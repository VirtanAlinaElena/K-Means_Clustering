% computes a clustering solution total cost
function cost = compute_cost_pc(points, centroids)
	cost = 0; 
  sumCluster = [];
 
  linPoints = size(points, 1);
  linCentroids = size(centroids, 1);
  indices = zeros(linPoints, 1);
  
  for i = 1 : linPoints
    k = 1; 
    distMin = sum((points(i, :) - centroids(1,:)) .^ 2);
    for j = 2 : linCentroids
      dist = sum((points(i, :) - centroids(j, :)) .^ 2);
      if (dist < distMin )
        distMin = dist;
        k = j;
      endif
    endfor
    indices(i) = k;
  endfor
    
  for i = 1 : linCentroids
    sum = 0;
    % matricea coordonatelor punctelor care apartin clusterului i  
    x = points(indices == i, :);
    
    % numarul de puncte care apartin clusterului i 
    nr = size(x, 1);
    
    for j = 1 : nr
      sum += norm(centroids(i, :) - x(j, :));
    endfor
    
   % costul clusterului i 
    sumCluster(i) = sum;
  endfor
  
   % suma costurilor tuturor clusterelor
  for i = 1 : linCentroids
    cost += sumCluster(i);
  endfor
end

