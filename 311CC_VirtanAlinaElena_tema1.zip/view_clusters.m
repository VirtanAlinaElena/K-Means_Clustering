function [] = view_clusters(points, centroids)
  % memorez in matricea indices clusterul din care face parte fiecare punct
  linPoints = size(points, 1);
  linCentroids = size(centroids, 1); 
  for i = 1 : linPoints
    k = 1; 
    distMin = sum((points(i, :) - centroids(1,:)) .^ 2);
    for j = 2 : linCentroids
      dist = sum((points(i, :) - centroids(j, :)) .^ 2);
      if (dist < distMin )
        distMin = dist;
        k = j;
      endif
    endfor
    indices(i) = k;
  endfor
  
  % initializez un vector de culori
  colors = ['r' 'g' 'b' 'y' 'c' 'm' 'k']; 
  
  hold on;
  for i = 1 : size(centroids, 1)
    % memorez in xi coordonatele x ale punctelor din clusterul i
    % memorez in yi coordonatele y ale punctelor din clusterul i 
    % memorez in zi coordonatele z ale punctelor din clusterul i
    xi = points(indices == i, 1);
    yi = points(indices == i, 2);
    zi = points(indices == i, 3);
    % reprezentarea grafica a punctelor din clusterul i
    scatter3(xi', yi', zi', 30, colors(i), 'filled');    
  endfor 
  hold off;
 
  title('Reprezentare grafica');
  xlabel('Coordonata x');
  ylabel('Coordonata y');
  zlabel('Coordonata z');
endfunction